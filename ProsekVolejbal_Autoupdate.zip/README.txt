PROSEK VOLEJBAL — Safari / iPhone

Toto je PWA (webová aplikace), kterou lze na iPhonu přidat na plochu přes Safari.

DŮLEŽITÉ:
- Safari vyžaduje HTTPS webovou adresu pro instalaci jako aplikace.
- Samotný ZIP nelze v Safari nainstalovat přímo.
- Po nahrání obsahu na HTTPS hosting otevři stránku v Safari -> Sdílet -> Přidat na plochu.

Oficiální zdroj rozpisů: Český volejbalový svaz (ČVS).
Data v této verzi obsahují ověřené termíny, které byly dostupné při sestavení. U ČVS jsou některé kalendáře dostupné přes jejich iCalendar export; pro úplný automatický import je vhodné napojit tento export na serverovou aktualizaci.
